"""Fill the official NeurIPS checklist template in place, question by question.

Reads paper/checklist.tex, strips the instruction block the template tells you to
delete, and replaces the 16 \\answerTODO{} / \\justificationTODO{} pairs in order.
The questions, guidelines and macros are left byte-for-byte untouched, as the template
requires.
"""
from __future__ import annotations

import os
import re

# The official NeurIPS template, shipped alongside so this script is self-contained.
SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "checklist_template.tex")
DST = os.path.join(os.path.dirname(os.path.abspath(__file__)), "checklist_filled.tex")

# (answer macro, justification) in template order.
ANSWERS = [
    # 1. Claims
    ("Yes",
     "Every headline number in the abstract and Section~\\ref{sec:intro} is produced by "
     "an experiment in this paper: the within-run coverage figures and the agent "
     "self-report baselines come from Section~\\ref{sec:within} and "
     "Table~\\ref{tab:a2}, the ``18 of 19'' breadth claim is read off the windowed-CQR "
     "column of Table~\\ref{tab:b1}, the joint-coverage figures from "
     "Table~\\ref{tab:multires}, and the 86.3\\% doomed-run saving and the Cost-of-Pass "
     "reduction from Section~\\ref{sec:econ} at the $\\delta = 0.10$ operating point "
     "defined in Appendix~\\ref{app:stopping}. The abstract states the scope limits "
     "that matter: the within-run range is Claude Opus 4.7 only, the 0.95 joint "
     "coverage is in-distribution and falls to 0.71 under a model swap, and the "
     "economic figures are counterfactual replays. The abstract and "
     "Section~\\ref{sec:econstop} are explicit that the stopping rule thresholds a "
     "feasibility score and does not read the remaining-budget intervals."),
    # 2. Limitations
    ("Yes",
     "Section~\\ref{sec:limits} states that the joint multi-resource result rests "
     "entirely on one environment and does not survive a model swap, that the breadth "
     "counts come from a single split rather than a seed average and that on it one run "
     "falls short for windowed-CQR and five for DtACI, "
     "that marginal coverage can hide under-coverage in slices such as early turns, "
     "that coverage alone does not distinguish a useful interval from a trivially wide "
     "one, and that the economic figures are counterfactual replays rather than live "
     "measurements. Appendix~\\ref{app:protocol} adds the assumption-level caveats: the "
     "deliberate deviation from canonical ACI, and the interpolated labels with "
     "12--27\\% median relative error behind censored-stratum coverage for capacity and "
     "cost. Table~\\ref{tab:a1} marks which components carry no finite-sample "
     "guarantee."),
    # 3. Theory assumptions and proofs
    ("NA",
     "The paper states and proves no new theoretical results. Every guarantee it "
     "invokes is imported from prior work (split-conformal marginal coverage, Mondrian "
     "conditional validity, ACI/DtACI long-run coverage, the Bonferroni union bound, "
     "conformal risk control), and Table~\\ref{tab:a1} records for each component what "
     "is guaranteed, under what assumption, and over what object --- including the "
     "components for which we claim no guarantee and report empirical results only."),
    # 4. Experimental result reproducibility
    ("Yes",
     "Appendix~\\ref{app:protocol} specifies everything needed to rebuild the pipeline: "
     "the by-rollout 50/25/25 split with seeds 0--4 and the exact RNG "
     "(\\ref{app:splits}), the rollout-safe label-revelation protocol, the LightGBM "
     "settings and the complete feature list with its enforced leak set, the "
     "finite-sample corrected quantile and the settings of every conformal variant "
     "including window length, ACI step-size selection and the DtACI expert grid, all "
     "seven baselines (\\ref{app:baselines}), the definition of every reported metric "
     "and the cluster bootstrap (\\ref{app:metrics}), the joint and censored "
     "calibration variants (\\ref{app:joint}), and the stopping-rule calibration and "
     "$\\delta$ sweep (\\ref{app:stopping}). Appendix~\\ref{app:repro} pins the input "
     "data to a single dataset revision and the software environment to a "
     "digest-pinned container with a hash-locked requirements file."),
    # 5. Open access to data and code
    ("No",
     "The data is fully open: every input is a public BAGEN logged rollout, fetched at "
     "the pinned revision recorded in Appendix~\\ref{app:repro} by a download script, so "
     "anyone can obtain exactly the inputs we used. The code is not attached to this "
     "submission. We will release the full pipeline publicly under an MIT licence on "
     "acceptance, together with the digest-pinned Dockerfile, the hash-locked "
     "requirements file, and the single entry point that regenerates every figure and "
     "table in the paper and machine-verifies 11 headline claims and all 35 quantitative "
     "claims against what it just produced, exiting non-zero on any mismatch. In the "
     "meantime Appendix~\\ref{app:protocol} specifies the split procedure, every "
     "hyperparameter, every baseline, every metric formula and the exact software "
     "versions, which is what an independent reimplementation needs."),
    # 6. Experimental setting/details
    ("Yes",
     "Section~\\ref{sec:setup} gives the environments and their budgets "
     "(Table~\\ref{tab:envs}), the 50/25/25 by-rollout split, the five seeds, the three "
     "shift scenarios, the seven agents and the resulting 19 model$\\times$environment "
     "runs, and the comparator list. Appendix~\\ref{app:protocol} gives the rest: the "
     "split procedure, the LightGBM hyperparameters shared by the quantile regressors, "
     "the absolute-residual baseline and the feasibility classifier, the full feature "
     "matrix, $\\alpha = 0.10$ throughout, and the exact sweep grids for the hard-cap "
     "baselines, the feasibility gate and $\\delta$. No hyperparameter search was run; "
     "the settings are project defaults used unchanged for the guard and for every "
     "baseline."),
    # 7. Experiment statistical significance
    ("Yes",
     "Every headline number is a mean over five disjoint rollout-level split seeds "
     "(Section~\\ref{sec:setup}, Appendix~\\ref{app:splits}). Figure~\\ref{fig:coverage} "
     "carries across-seed standard-deviation error bars and Table~\\ref{tab:a2} reports "
     "the same quantity as a $\\pm$ beside each coverage value; the caption and "
     "Appendix~\\ref{app:metrics} state which is which. Appendix~\\ref{app:metrics} "
     "also specifies the interval construction: a cluster bootstrap resampling whole "
     "rollouts rather than prefixes, $B = 500$ resamples, pooling per-seed draws and "
     "reporting the 5th and 95th percentiles. The clustering is deliberate --- prefixes "
     "of one rollout are correlated, so per-sample binomial intervals would be too "
     "tight --- and we note that averaging per-seed interval endpoints, which an earlier "
     "revision did, is not a confidence interval at any level."),
    # 8. Experiments compute resources
    ("Yes",
     "Appendix~\\ref{app:repro} states that the entire pipeline is CPU-only: no GPU, no "
     "model weights, and no access to logits or environment internals. No LLM is "
     "trained, fine-tuned or queried by us at any stage --- all agent rollouts are "
     "pre-existing logged data --- so the compute cost of the work is the cost of "
     "fitting gradient-boosted trees on tables of at most a few thousand rows. All "
     "experiments, including every ablation and sweep reported here and the variants "
     "that did not make the paper, run inside one digest-pinned container on a "
     "commodity CPU machine and reproduce bit-identically across host architectures "
     "apart from one-ulp differences in interval widths."),
    # 9. Code of ethics
    ("Yes",
     "We have reviewed the NeurIPS Code of Ethics and believe this work conforms. The "
     "research uses only an existing, publicly released dataset of logged agent "
     "rollouts at a pinned revision (Appendix~\\ref{app:repro}); it involves no human "
     "subjects, no crowdsourced labour, no personal or identifiable data, and no new "
     "model release. The submission is anonymised, and the released code is a CPU-only "
     "statistical calibration layer that neither generates content nor modifies the "
     "agents it wraps."),
    # 10. Broader impacts
    ("Yes",
     "Section~\\ref{sec:limits} contains an explicit broader-impact paragraph. The "
     "positive impact is the paper's stated goal and is quantified in "
     "Section~\\ref{sec:econ}: calibrated early stopping avoids 86.3\\% of the spend on "
     "trajectories that cannot finish and roughly halves Cost-of-Pass, reducing wasted "
     "compute, energy and money. The corresponding negative impact is that a threshold "
     "set too aggressively terminates runs that would have succeeded; the mitigation is "
     "the rollout-level $\\delta$ calibration of Section~\\ref{sec:econstop} and "
     "Appendix~\\ref{app:stopping}, which bounds that probability at a user-chosen "
     "level, and we caution that the counterfactual nature of the savings estimate "
     "means a deployer should not treat them as a guaranteed live return when choosing "
     "$\\delta$."),
    # 11. Safeguards
    ("NA",
     "The release poses no misuse risk requiring safeguards: we release no model "
     "weights, no pretrained language model, no generative capability, and no scraped "
     "data. The artifact is CPU-only calibration code over usage-accounting features "
     "whose only effect is to stop an agent's own run earlier, and we do not "
     "redistribute the BAGEN rollouts --- the released script downloads them from the "
     "upstream public repository at a pinned revision "
     "(Appendix~\\ref{app:repro})."),
    # 12. Licenses for existing assets
    ("Yes",
     "Every existing asset is cited to its originators and pinned to an exact version. "
     "The logged rollouts are from BAGEN~\\citep{lin2026bagen}, obtained from its public "
     "Hugging Face release at the revision recorded in Appendix~\\ref{app:repro} and "
     "and credited to its originators. Its dataset card states no licence, so we assert "
     "none on its behalf rather than inventing terms; the conformal, survival and economic "
     "methods we build on are cited at each point of use and summarised in "
     "Table~\\ref{tab:a1}. Appendix~\\ref{app:repro} lists the software stack with "
     "exact versions and licences: LightGBM (MIT), numpy, pandas, scipy and "
     "scikit-learn (BSD-3-Clause), and matplotlib (PSF-style). Our own released code is "
     "MIT-licensed and redistributes none of these assets."),
    # 13. New assets
    ("NA",
     "No new asset is released with this submission. The \\bg{} implementation will be "
     "released under an MIT licence on acceptance, documented by a README with the exact "
     "commands, a digest-pinned Dockerfile and hash-locked requirements file, a test "
     "suite, and two checkers that verify the reported claims against the regenerated "
     "tables; Appendix~\\ref{app:protocol} already names the module implementing each "
     "documented setting. No new dataset is created either: the derived per-prefix "
     "tables are regenerated from the public BAGEN release by the fetch and extraction "
     "scripts described in Appendix~\\ref{app:repro}."),
    # 14. Crowdsourcing and research with human subjects
    ("NA",
     "The paper involves no crowdsourcing and no human subjects. All experiments are "
     "offline analyses of pre-existing logged agent rollouts from the public BAGEN "
     "dataset (Section~\\ref{sec:setup}, Appendix~\\ref{app:repro}); we collected no new "
     "data from people and employed no annotators."),
    # 15. IRB
    ("NA",
     "No human subjects were involved at any stage, so no IRB review or equivalent "
     "approval was required. The study consists entirely of statistical calibration "
     "applied to a previously released public dataset of machine-generated agent "
     "trajectories."),
    # 16. Declaration of LLM usage
    ("NA",
     "No LLM is a component of the core method. \\bg{} requires no LLM fine-tuning and "
     "is model-agnostic: its predictors are gradient-boosted trees over "
     "usage-accounting features, and it reads no weights, logits or model outputs "
     "beyond the agent's optional self-reported interval (Section~\\ref{sec:method}, "
     "Appendix~\\ref{app:protocol}). We neither train, fine-tune nor query any LLM in "
     "this work; the seven agents named in Section~\\ref{sec:setup} are the sources of "
     "the pre-existing logged rollouts we analyse, not components of the method."),
]


def main() -> None:
    src = open(SRC).read()

    # The template instructs: delete the instruction block, keep the section heading.
    start = src.index("%%% BEGIN INSTRUCTIONS %%%")
    end = src.index("%%% END INSTRUCTIONS %%%") + len("%%% END INSTRUCTIONS %%%")
    src = src[:start] + src[end:]

    n_ans = src.count("\\answerTODO{}")
    n_jus = src.count("\\justificationTODO{}")
    if n_ans != len(ANSWERS) or n_jus != len(ANSWERS):
        raise SystemExit(f"template has {n_ans} answers / {n_jus} justifications, "
                         f"but {len(ANSWERS)} were prepared")

    # One pass, so answers and justifications stay paired in template order.
    state = {"i": -1}

    def repl(m):
        if m.group(0).startswith("\\answerTODO"):
            state["i"] += 1
            return "\\answer" + ANSWERS[state["i"]][0] + "{}"
        return ANSWERS[state["i"]][1]

    src = re.sub(r"\\answerTODO\{\}(\s*%[^\n]*)?|\\justificationTODO\{\}",
                 repl, src)

    open(DST, "w").write(src)
    print(f"wrote {DST} ({len(ANSWERS)} questions answered)")


if __name__ == "__main__":
    main()
