"""Emit LaTeX table bodies from tables/*.csv so no number is retyped by hand.

Writes one \\input-able fragment per table into tab_*.tex. Every fragment contains
only rows; the surrounding table/tabular environment and the caption live in the
paper source, so formatting stays in one place.
"""
from __future__ import annotations

import csv
import os

TABLES = "/mnt/user-data/uploads/budget-guard/tables"
OUT = os.path.dirname(os.path.abspath(__file__))

ENV = {"sokoban": "Sokoban", "searchr1": "Search-R1", "swebench": "SWE-bench"}
ENV_ORDER = ("sokoban", "searchr1", "swebench")
MODEL_ORDER = ("Claude Opus 4.7", "Claude Opus 4.6", "Claude Sonnet 4.6",
               "GPT-5.2-instant", "GPT-5.2-Codex", "Gemini 3.1 Pro", "Qwen3-235B")
MODEL_RULES = (("codex", "GPT-5.2-Codex"), ("gpt5.2", "GPT-5.2-instant"),
               ("gpt-5.2", "GPT-5.2-instant"), ("gemini", "Gemini 3.1 Pro"),
               ("qwen", "Qwen3-235B"), ("sonnet", "Claude Sonnet 4.6"))
METHOD_ORDER = ["agent self-report", "constant-quantile", "split-absres", "split-CQR",
                "conformalized-agent", "guard+self-est", "ACI-CQR", "windowed-CQR",
                "DtACI"]


def rd(name):
    with open(os.path.join(TABLES, name)) as fh:
        return list(csv.DictReader(fh))


def model_name(label: str) -> str:
    low = label.lower()
    for needle, name in MODEL_RULES:
        if needle in low:
            return name
    if "opus" in low:
        return "Claude Opus 4.7" if ("4.7" in low or "4-7" in low) else "Claude Opus 4.6"
    raise SystemExit(f"unrecognized run label: {label!r}")


def f2(x, nd=2):
    if x in ("", None):
        return "--"
    v = float(x)
    if v != v:
        return "--"
    if v == float("inf"):
        return "--"
    return f"{v:.{nd}f}"


def write(name, colspec, header, lines):
    """Emit a complete tabular.

    The whole environment lives here rather than just the rows, because \input
    inside an alignment breaks it ("Misplaced \noalign") on this TeX Live: the
    file boundary lands mid-row. \input at table level is safe. Captions,
    labels, placement and font size stay in the paper source.
    """
    body = ["\\begin{tabular}{%s}" % colspec, "\\toprule"] + header + \
        ["\\midrule"] + lines + ["\\bottomrule", "\\end{tabular}"]
    with open(os.path.join(OUT, name), "w") as fh:
        fh.write("\n".join(body) + "\n")
    print("wrote", name)


# ------------------------------------------------------------- Table 2 (main)
def table_multiresource():
    ind = {r["scheme"]: r for r in rd("multiresource.csv")}
    swap = rd("transfer_warehouse.csv")

    def swap_joint(method):
        vals = [float(r["coverage"]) for r in swap
                if r["method"] == method and "ALL" in r["resource"]]
        return sum(vals) / len(vals) if vals else None

    rows = [
        ("agent self-report", "agent self-report", "agent self-report"),
        ("independent margins ($\\alpha$)", "independent", None),
        ("Bonferroni ($\\alpha/3$)", "bonferroni", "frozen Bonferroni"),
        ("empirical copula", "copula", "frozen joint copula"),
    ]
    out = []
    for label, ikey, skey in rows:
        r = ind[ikey]
        sw = swap_joint(skey) if skey else None
        joint_ind = f2(r["joint"])
        if ikey == "bonferroni":
            joint_ind = "\\textbf{" + joint_ind + "}"
        out.append(f"{label} & {f2(r['time_weeks'])} & {f2(r['warehouse_item_weeks'])} "
                   f"& {f2(r['cost_usd'])} & {joint_ind} & "
                   f"{f2(sw) if sw is not None else '--'} \\\\")
    ad = swap_joint("adaptive joint copula")
    out.append("adaptive copula (online) & -- & -- & -- & -- & \\textbf{"
               + f2(ad) + "} \\\\")
    header = [
        "& \\multicolumn{3}{c}{per-resource coverage} "
        "& \\multicolumn{2}{c}{joint coverage} \\\\",
        "\\cmidrule(lr){2-4} \\cmidrule(lr){5-6}",
        "Calibration scheme & time & capacity & cost & in-distribution & "
        "model swap \\\\",
    ]
    write("tab_multiresource.tex", "lccccc", header, out)


# ------------------------------------------------------------ Table A2
def table_a2():
    rows = rd("coverage.csv")
    by = {(r["env"], r["method"]): r for r in rows}
    out = []
    for ei, env in enumerate(ENV_ORDER):
        if ei:
            out.append("\\midrule")
        # best bounded coverage-to-target and narrowest width, for bolding
        cand = [(m, by[(env, m)]) for m in METHOD_ORDER if (env, m) in by]
        bounded = [(m, r) for m, r in cand
                   if r["normalized_width"] not in ("", "inf") and m != "agent self-report"]
        best_cov = min(bounded, key=lambda t: abs(float(t[1]["coverage"]) - 0.90))[0]
        best_w = min(bounded, key=lambda t: float(t[1]["normalized_width"]))[0]
        for j, (m, r) in enumerate(cand):
            name = ENV[env] if j == 0 else ""
            cov = f2(r["coverage"])
            std = r["coverage_std"]
            cov_s = cov if m == "agent self-report" else f"{cov} $\\pm$ {f2(std)}"
            if m == best_cov:
                cov_s = "\\textbf{" + cov_s + "}"
            w = f2(r["normalized_width"])
            if m == best_w and w != "--":
                w = "\\textbf{" + w + "}"
            unb = "--" if r["frac_unbounded"] == "" else f"{float(r['frac_unbounded'])*100:.0f}"
            n = "--" if r["n_test"] == "" else f"{float(r['n_test']):.0f}"
            out.append(f"{name} & {m} & {cov_s} & {w} & {unb} & {n} \\\\")
    header = ["Environment & Method & Coverage & Norm.\\ width ($\\downarrow$) "
              "& Unb.\\ (\\%) & $n_{\\mathrm{test}}$ \\\\"]
    write("tab_a2.tex", "llcccc", header, out)


# ------------------------------------------------------------ Table B1
def table_b1():
    rows = rd("allruns.csv")
    if len(rows) != 19:
        raise SystemExit(f"expected 19 runs, got {len(rows)}")
    rows.sort(key=lambda r: (ENV_ORDER.index(r["env"]),
                             MODEL_ORDER.index(model_name(r["model"]))))
    out = []
    prev = None
    for r in rows:
        if prev is not None and r["env"] != prev:
            out.append("\\midrule")
        name = ENV[r["env"]] if r["env"] != prev else ""
        prev = r["env"]
        # Four decimals: at three, SWE-bench/Gemini DtACI prints as 0.850 and the
        # ">= 0.85" count in Section 5.1 stops being checkable off the column.
        cells = {k: f2(r[k], 4) for k in ("split-CQR", "windowed-CQR", "DtACI")}
        near = [k for k in cells if cells[k] != "--"]
        if near:
            # Bold every method tied for closest-to-nominal. Picking one winner out of an
            # exact tie (Sokoban/Opus 4.7 has two at 0.9000) reads as a result it isn't.
            gap = {k: abs(float(r[k]) - 0.90) for k in near}
            best = min(gap.values())
            for k in near:
                if gap[k] == best:
                    cells[k] = "\\textbf{" + cells[k] + "}"
        out.append(
            f"{name} & {model_name(r['model'])} & {int(float(r['n_rollouts']))} & "
            f"{int(float(r['n_samples'])):,} & {f2(r['agent'], 3)} & "
            f"{cells['split-CQR']} & {cells['windowed-CQR']} & "
            f"{cells['DtACI']} \\\\".replace(",", "{,}"))
    wh = [r for r in rd("transfer_warehouse.csv") if r["method"] == "frozen Bonferroni"]
    rolls = {int(float(r["n_rollouts"])) for r in wh}
    feas = {int(float(r["n_test"])) for r in wh}
    tgts = sorted({r["target_model"] for r in wh})
    if len(rolls) != 1 or len(feas) != 1:
        raise SystemExit("Warehouse targets disagree on counts")
    ind = {r["scheme"]: r for r in rd("multiresource.csv")}
    out.append("\\midrule")
    out.append(f"Warehouse & Opus 4.7 $+$ {len(tgts)} swap targets & {rolls.pop()} ea. & "
               f"{feas.pop()*2:,} ea. & {f2(ind['agent self-report']['joint'], 3)}$^{{\\dagger}}$ "
               f"& -- & -- & -- \\\\".replace(",", "{,}"))
    header = ["Environment & Model & Rollouts & Prefixes & Agent "
              "& \\multicolumn{3}{c}{coverage, closest to nominal 0.90 in bold} \\\\",
              "\\cmidrule(lr){6-8}",
              " & & & & & split-CQR & windowed-CQR & DtACI \\\\"]
    write("tab_b1.tex", "llrrcccc", header, out)


# ------------------------------------------------------------ Table B2
def table_b2():
    rows = rd("conditional_coverage.csv")
    slices = ("marginal", "k=1", "k=2", "k>=3")
    out = []
    for ei, env in enumerate(ENV_ORDER):
        if ei:
            out.append("\\midrule")
        per = {}
        for method in ("split-CQR", "Mondrian-CQR"):
            per[method] = {r["slice"]: r["coverage"] for r in rows
                           if r["env"] == env and r["method"] == method}
        for j, method in enumerate(("split-CQR", "Mondrian-CQR")):
            got = per[method]
            if not got:
                continue
            name = ENV[env] if j == 0 else ""
            cells = []
            for sl in slices:
                if sl not in got:
                    cells.append("--")
                    continue
                mine, other = float(got[sl]), per[
                    "Mondrian-CQR" if method == "split-CQR" else "split-CQR"].get(sl)
                txt = f2(got[sl])
                # "<=" so an exact tie bolds both rather than neither.
                if other is not None and abs(mine - 0.90) <= abs(float(other) - 0.90):
                    txt = "\\textbf{" + txt + "}"
                cells.append(txt)
            out.append(f"{name} & {method} & {' & '.join(cells)} \\\\")
    header = ["Environment & Method & Marginal & $k=1$ & $k=2$ & $k \\ge 3$ \\\\",
              "\\multicolumn{6}{l}{\\footnotesize Coverage against nominal 0.90; the "
              "value closer to nominal in each column is bold.} \\\\"]
    write("tab_b2.tex", "llcccc", header, out)


# ------------------------------------------------------------ Table B3
def table_b3():
    rows = rd("gated_intervals.csv")
    label = {"time_weeks": "time (weeks)",
             "warehouse_item_weeks": "capacity (item-weeks)",
             "cost_usd": "cost (USD)"}
    out = []
    for ri, res in enumerate(("time_weeks", "warehouse_item_weeks", "cost_usd")):
        if ri:
            out.append("\\midrule")
        rs = [r for r in rows if r["resource"] == res]
        rs.sort(key=lambda r: float(r["delta"]))
        for j, r in enumerate(rs):
            name = label[res] if j == 0 else ""
            out.append(f"{name} & {f2(r['delta'])} & {f2(r['kept_frac'])} & "
                       f"{f2(r['gate_catch_doomed'])} & {f2(r['false_abort_feasible'])} & "
                       f"{f2(r['cov_kept_feasible'])} \\\\")
    header = ["Resource & $\\delta$ & Kept ($\\uparrow$) & Caught ($\\uparrow$) "
              "& False abort ($\\downarrow$) & Coverage ($\\uparrow$) \\\\"]
    write("tab_b3.tex", "lccccc", header, out)


# ------------------------------------------------------------ Table B4 (censored)
def table_b4():
    rows = rd("censored_upper.csv")
    label = {"time_weeks": "time (weeks)",
             "warehouse_item_weeks": "capacity (item-weeks)",
             "cost_usd": "cost (USD)"}
    meth = {"drop": "drop (naive)", "infinity": "$+\\infty$", "bound": "substituted bound",
            "ipcw": "IPCW", "resource_bound": "per-resource bound",
            "km": "Kaplan--Meier (diagnostic)"}
    out = []
    for ri, res in enumerate(("time_weeks", "warehouse_item_weeks", "cost_usd")):
        if ri:
            out.append("\\midrule")
        rs = [r for r in rows if r["resource"] == res]
        # "infinity" is vacuously 1.00 and "km" is a diagnostic, so neither competes.
        informative = [r for r in rs if r["method"] not in ("infinity", "km")]
        best = max((float(r["cov_cens_binding"]) for r in informative), default=None)
        for j, r in enumerate(rs):
            name = label[res] if j == 0 else ""
            cb = f2(r["cov_cens_binding"])
            competing = r["method"] not in ("infinity", "km")
            if best is not None and competing and float(r["cov_cens_binding"]) == best:
                cb = "\\textbf{" + cb + "}"
            out.append(f"{name} & {meth.get(r['method'], r['method'])} & "
                       f"{f2(r['cov_feasible'])} & {cb} & "
                       f"{f2(r['cov_cens_nonbinding'])} & {f2(r['frac_binding'])} \\\\")
    header = ["Resource & Treatment & Feasible & \\multicolumn{2}{c}{Censored} "
              "& Binding \\\\",
              "\\cmidrule(lr){4-5}",
              " & & ($\\uparrow$0.90) & binding & non-binding & fraction \\\\"]
    write("tab_b4.tex", "llcccc", header, out)


if __name__ == "__main__":
    table_multiresource()
    table_a2()
    table_b1()
    table_b2()
    table_b3()
    table_b4()
