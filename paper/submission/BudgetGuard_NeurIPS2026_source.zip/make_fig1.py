"""Figure 1: the Budget Guard pipeline, drawn at NeurIPS text width (5.5 in).

Same schematic as the working version in scripts/make_pipeline_figure.py, re-laid-out
for a 5.5 in text block: the conformal-layer detail panel is dropped (it duplicates
Table A1) so the four prefix-feature families and the four pipeline stages can be set
at legible point sizes at 1:1 placement.
"""
from __future__ import annotations

import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Polygon

AQUA, VIOLET, GREEN, GRAY, ORANGE = "#1baf7a", "#4a3aa7", "#008300", "#8B93A1", "#eb6834"
INK, MUTED = "#2b3240", "#5b6473"

FIG_W, FIG_H = 5.5, 2.85
FS_STAGE, FS_SUB = 7.2, 6.1
FS_PANEL, FS_HEAD, FS_BODY, FS_NOTE = 7.0, 6.4, 6.0, 5.7
OUT = os.path.dirname(os.path.abspath(__file__))


def rbox(ax, x, y, w, h, color, *, fill=0.06, lw=1.0, ls="solid", z=2):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.004,rounding_size=0.010",
                                linewidth=0, facecolor=color, alpha=fill, zorder=z - 1))
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.004,rounding_size=0.010",
                                linewidth=lw, edgecolor=color, facecolor="none",
                                linestyle=ls, zorder=z))


def stage(ax, n, x, y, w, h, color, title, subtitle):
    rbox(ax, x, y, w, h, color)
    ax.add_patch(Circle((x + 0.021, y + h - 0.043), 0.0135, facecolor=color,
                        edgecolor="none", zorder=4))
    ax.text(x + 0.021, y + h - 0.045, str(n), ha="center", va="center", fontsize=5.8,
            fontweight="bold", color="white", zorder=5)
    ax.text(x + w / 2 + 0.016, y + h - 0.043, title, ha="center", va="center",
            fontsize=FS_STAGE, fontweight="bold", color=color, zorder=4)
    ax.text(x + w / 2, y + h - 0.095, subtitle, ha="center", va="top", fontsize=FS_SUB,
            color=INK, linespacing=1.45, zorder=4)


def arrow(ax, x0, y0, x1, y1, color=INK, lw=1.1):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=8,
                                 linewidth=lw, color=color, zorder=3))


def card(ax, x, y, w, h, color, head, body):
    rbox(ax, x, y, w, h, color, fill=0.045, lw=0.85)
    ax.text(x + 0.013, y + h - 0.040, head, ha="left", va="center", fontsize=FS_HEAD,
            fontweight="bold", color=color)
    ax.text(x + 0.013, y + h - 0.078, body, ha="left", va="top", fontsize=FS_BODY,
            color=INK, linespacing=1.5)


def main() -> None:
    fig = plt.figure(figsize=(FIG_W, FIG_H))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    ty, th = 0.640, 0.250
    sw, gap = 0.226, 0.026
    xs = [0.008 + i * (sw + gap) for i in range(4)]

    stage(ax, 1, xs[0], ty, sw, th, GRAY, "Agent run",
          "any LLM agent,\nunmodified; per-turn\nspend at turn $k$")
    stage(ax, 2, xs[1], ty, sw, th, AQUA, "Prefix features",
          "four families, all\nreadable from the\nturns so far")
    stage(ax, 3, xs[2], ty, sw, th, VIOLET, "Conformal layer",
          "turns a point estimate\ninto an interval with a\ncoverage guarantee")
    stage(ax, 4, xs[3], ty, sw, th, GREEN, "Per-turn decision",
          "calibrated interval on\nthe remaining budget,\nplus continue-or-abort")

    mid = ty + th / 2
    for i in range(3):
        arrow(ax, xs[i] + sw + 0.004, mid, xs[i + 1] - 0.004, mid)

    ax.text(0.008, 0.998, "training-free  •  model-agnostic  •  no weights, no logits, no GPU",
            ha="left", va="top", fontsize=FS_NOTE, color=MUTED)

    yfb = 0.955
    x_from, x_to = xs[3] + sw / 2, xs[2] + sw / 2
    ax.plot([x_from, x_from], [ty + th + 0.004, yfb], color=ORANGE, lw=1.0)
    ax.plot([x_from, x_to], [yfb, yfb], color=ORANGE, lw=1.0)
    arrow(ax, x_to, yfb, x_to, ty + th + 0.006, color=ORANGE, lw=1.0)
    ax.text((x_from + x_to) / 2, yfb + 0.014,
            "labels feed back only once a rollout finishes (never mid-run)",
            ha="center", va="bottom", fontsize=FS_NOTE, color=ORANGE)

    py, ph = 0.020, 0.520
    px, pw = 0.008, 0.984
    ax.add_patch(Polygon([(xs[1], ty - 0.028), (xs[1] + sw, ty - 0.028),
                          (px + pw, py + ph), (px, py + ph)], closed=True,
                         facecolor=AQUA, alpha=0.045, edgecolor="none", zorder=0))
    for a, b in (((xs[1], ty - 0.028), (px, py + ph)),
                 ((xs[1] + sw, ty - 0.028), (px + pw, py + ph))):
        ax.plot([a[0], b[0]], [a[1], b[1]], color=AQUA, lw=0.7, ls=(0, (3, 3)),
                alpha=0.5, zorder=0)
    rbox(ax, px, py, pw, ph, AQUA, fill=0.02, lw=0.95, ls=(0, (5, 3)))
    ax.text(px + 0.016, py + ph - 0.045, "2   The four prefix-feature families",
            ha="left", va="center", fontsize=FS_PANEL, fontweight="bold", color=AQUA)

    cw, ch = 0.470, 0.148
    gx0, gx1 = px + 0.016, px + 0.016 + cw + 0.020
    gy0, gy1 = py + ph - 0.238, py + ph - 0.400

    card(ax, gx0, gy0, cw, ch, AQUA, "1.  Progress", "turn index $k$")
    card(ax, gx1, gy0, cw, ch, AQUA, "2.  Cumulative consumption",
         "spend so far; burn rate (spend / $k$)")
    card(ax, gx0, gy1, cw, ch, AQUA, "3.  Recent usage",
         "last / mean / sd / min / max per-turn\nspend; last-3 mean; last $-$ mean")
    card(ax, gx1, gy1, cw, ch, AQUA, "4.  Agent self-estimate",
         "optional; the agent's own interval:\nendpoints, midpoint, width")

    ax.text(px + pw / 2, py + 0.045,
            "Excluded by construction: final totals, success, feasibility — anything known only at\n"
            "rollout end. Their absence is asserted in code, not merely intended.",
            ha="center", va="center", fontsize=FS_NOTE, color=MUTED, linespacing=1.55)

    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(OUT, f"fig1_pipeline.{ext}"), dpi=400, facecolor="white")
    print("wrote fig1_pipeline.pdf / .png")


if __name__ == "__main__":
    main()
