# Budget Guard - Overleaf build (final draft, 2026-08-24)

Upload this zip to Overleaf as a new project (New Project -> Upload Project).
It is self-contained: main file is budget_guard.tex, bibliography is embedded
(no .bib / BibTeX run needed), figures and the NeurIPS style are included.

Compiles with pdfLaTeX (Overleaf default).

Contents:
- budget_guard.tex   the paper (identical to repo paper/drafts/2026-08-24_final_draft.tex)
- neurips_2026.sty   official NeurIPS 2026 style, unmodified
- fig1_pipeline.pdf, fig2_coverage.pdf, fig3_transfer.pdf, fig4_economics.pdf

This version is the 2026-08-23 condensed revision with exactly five fixes:
abstract/conclusion "on one split each"; checklist Q1/Q7 "headline number";
C.9 licence sentences restored; checklist in official template format;
verified full-author bibliography. Change log: repo paper/AUDIT_LOG.md.
