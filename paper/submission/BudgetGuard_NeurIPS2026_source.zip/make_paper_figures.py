"""Draw the four main-text figures at NeurIPS text width (5.5 in), from tables/.

Every value is read from the generated CSVs -- nothing is retyped. Differences from
the exploratory figures in figures/: no in-figure titles (the caption does that job),
paper-facing environment and method names, and point sizes chosen for 1:1 placement
in a 5.5 in text block.

Usage: python make_paper_figures.py
"""
from __future__ import annotations

import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

TABLES = "/mnt/user-data/uploads/budget-guard/tables"
OUT = os.path.dirname(os.path.abspath(__file__))

W = 5.5  # NeurIPS text width, inches
GRAY, RED, PINK, BLUE = "#8B93A1", "#e34948", "#e87ba4", "#2a78d6"
AQUA, ORANGE, YELLOW = "#1baf7a", "#eb6834", "#eda100"
VIOLET, GREEN, INK = "#4a3aa7", "#008300", "#2b3240"

plt.rcParams.update({
    "font.size": 7.0, "axes.labelsize": 7.4, "axes.titlesize": 7.6,
    "xtick.labelsize": 7.0, "ytick.labelsize": 7.0, "legend.fontsize": 6.6,
    "axes.edgecolor": "#c8ccd4", "axes.linewidth": 0.7,
    "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "grid.color": "#e6e9ee", "grid.linewidth": 0.6,
    "figure.dpi": 400, "savefig.dpi": 400,
})

ENV = {"sokoban": "Sokoban", "searchr1": "Search-R1", "swebench": "SWE-bench"}
MODEL = {"claude-sonnet4.6": "Claude Sonnet 4.6", "gemini3.1": "Gemini 3.1 Pro",
         "gpt5.2instant": "GPT-5.2-instant", "qwen3-235b": "Qwen3-235B"}


def rd(name):
    with open(os.path.join(TABLES, name)) as fh:
        return list(csv.DictReader(fh))


def num(x):
    if x is None or x == "":
        return float("nan")
    return float(x)


def nominal(ax, y=0.90, label=False):
    ax.axhline(y, ls=(0, (4, 3)), lw=0.8, color="#5b6473", zorder=1)


NOMINAL_HANDLE = Line2D([0], [0], ls=(0, (4, 3)), lw=0.9, color="#5b6473",
                        label="nominal 0.90")


def bars(ax, groups, methods, values, unbounded, colors, group_labels,
         value_fs=5.4, annotate=True, errs=None):
    """Grouped bars; hatched + annotated where a method emits unbounded intervals."""
    n_m = len(methods)
    width = 0.86 / n_m
    x = np.arange(len(groups))
    for j, m in enumerate(methods):
        off = (j - (n_m - 1) / 2) * width
        v = np.array([values[(g, m)] for g in groups], dtype=float)
        u = np.array([unbounded.get((g, m), 0.0) for g in groups], dtype=float)
        for i in range(len(groups)):
            if not np.isfinite(v[i]):
                continue
            hatched = np.isfinite(u[i]) and u[i] > 0.005
            e = None
            if errs is not None:
                ev = errs.get((groups[i], m))
                if ev is not None and np.isfinite(ev) and ev > 0:
                    e = ev
            ax.bar(x[i] + off, v[i], width=width * 0.92, color=colors[m],
                   edgecolor="white" if hatched else colors[m],
                   hatch="///" if hatched else None, linewidth=0.5, zorder=3,
                   yerr=e, error_kw=dict(ecolor="#3a4150", elinewidth=0.6, capsize=1.0))
            top = v[i] + (e or 0.0)
            if annotate:
                ax.text(x[i] + off, top + 0.018, f"{v[i]:.2f}", ha="center",
                        va="bottom", fontsize=value_fs, rotation=90, color=INK)
            if hatched:
                ax.text(x[i] + off, 0.045, f"∞{u[i]*100:.0f}%", ha="center",
                        va="bottom", fontsize=5.0, rotation=90, color="white",
                        zorder=4, fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(group_labels)
    ax.set_axisbelow(True)
    ax.yaxis.grid(True)
    ax.set_ylim(0, 1.30)
    ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])


# --------------------------------------------------------------- Figure 2
def figure2():
    rows = rd("coverage.csv")
    methods = ["agent self-report", "constant-quantile", "split-absres", "split-CQR",
               "conformalized-agent", "guard+self-est", "ACI-CQR", "windowed-CQR", "DtACI"]
    colors = {"agent self-report": GRAY, "constant-quantile": RED, "split-absres": BLUE,
              "split-CQR": AQUA, "conformalized-agent": PINK, "guard+self-est": ORANGE,
              "ACI-CQR": YELLOW, "windowed-CQR": VIOLET, "DtACI": GREEN}
    envs = ["sokoban", "searchr1", "swebench"]
    vals, unb, err = {}, {}, {}
    for r in rows:
        vals[(r["env"], r["method"])] = num(r["coverage"])
        unb[(r["env"], r["method"])] = num(r["frac_unbounded"])
        err[(r["env"], r["method"])] = num(r["coverage_std"])

    fig, ax = plt.subplots(figsize=(W, 2.5))
    bars(ax, envs, methods, vals, unb, colors, [ENV[e] for e in envs], errs=err)
    nominal(ax)
    ax.set_ylabel("marginal coverage")
    handles = [Patch(facecolor=colors[m], label=m) for m in methods]
    handles += [Patch(facecolor="white", edgecolor=INK, hatch="///",
                      label="unbounded intervals"), NOMINAL_HANDLE]
    ax.legend(handles=handles, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.11),
              frameon=False, handlelength=1.3, columnspacing=1.0, handletextpad=0.5)
    fig.savefig(os.path.join(OUT, "fig2_coverage.pdf"), bbox_inches="tight",
                pad_inches=0.01)
    plt.close(fig)


# --------------------------------------------------------------- Figure 3
def figure3():
    methods = ["split-CQR (frozen)", "ACI-CQR", "windowed-CQR", "DtACI"]
    colors = {"split-CQR (frozen)": AQUA, "ACI-CQR": YELLOW,
              "windowed-CQR": VIOLET, "DtACI": GREEN}

    env_rows = rd("transfer_env.csv")
    envs = ["searchr1", "swebench"]
    v1, u1 = {}, {}
    for r in env_rows:
        v1[(r["target_env"], r["method"])] = num(r["coverage"])
        u1[(r["target_env"], r["method"])] = num(r["frac_unbounded"])

    sw_rows = rd("transfer_swebench.csv")
    tms = ["claude-sonnet4.6", "gemini3.1", "gpt5.2instant", "qwen3-235b"]
    v2, u2 = {}, {}
    for r in sw_rows:
        v2[(r["target_model"], r["method"])] = num(r["coverage"])
        u2[(r["target_model"], r["method"])] = num(r["frac_unbounded"])

    fig, axes = plt.subplots(1, 2, figsize=(W, 2.45),
                             gridspec_kw={"width_ratios": [1, 1.9], "wspace": 0.06})
    bars(axes[0], envs, methods, v1, u1, colors,
         ["Search-R1", "SWE-bench"], value_fs=5.4)
    nominal(axes[0])
    axes[0].set_ylabel("coverage on the target stream")
    axes[0].set_title("(a) cross-environment,\ncalibrated on Sokoban", fontsize=6.9, pad=3)

    bars(axes[1], tms, methods, v2, u2, colors,
         ["Claude\nSonnet 4.6", "Gemini\n3.1 Pro", "GPT-5.2-\ninstant",
          "Qwen3-\n235B"], value_fs=5.4)
    nominal(axes[1])
    axes[1].set_title("(b) model swap on SWE-bench,\ncalibrated on Claude Opus 4.7",
                      fontsize=6.9, pad=3)
    axes[1].set_yticklabels([])

    handles = [Patch(facecolor=colors[m], label=m) for m in methods]
    handles += [Patch(facecolor="white", edgecolor=INK, hatch="///",
                      label="unbounded intervals"), NOMINAL_HANDLE]
    axes[0].legend(handles=handles, ncol=3, loc="upper center",
                   bbox_to_anchor=(1.62, -0.24), frameon=False, handlelength=1.3,
                   columnspacing=1.2, handletextpad=0.5)
    fig.savefig(os.path.join(OUT, "fig3_transfer.pdf"), bbox_inches="tight",
                pad_inches=0.01)
    plt.close(fig)


# --------------------------------------------------------------- Figure 4
def figure4():
    fr = rd("abort_frontier_warehouse.csv")
    cp = rd("cost_of_pass_warehouse.csv")

    def series(rows, rule_key, rule_val, xk, yk):
        pts = [(num(r[xk]), num(r[yk]), r["param"]) for r in rows
               if r[rule_key] == rule_val]
        pts.sort()
        return pts

    fig, axes = plt.subplots(1, 2, figsize=(W, 2.0), gridspec_kw={"wspace": 0.30})

    ax = axes[0]
    for name, colour, marker, style in (
            ("guard", VIOLET, "o", "-"),
            ("hard cap ($ spent)", YELLOW, "s", ":"),
            ("hard cap (weeks)", ORANGE, "^", ":")):
        pts = series(fr, "rule", name, "false_abort_rate", "doomed_savings_frac")
        ax.plot([p[0] for p in pts], [p[1] for p in pts], marker=marker, ms=3.0,
                lw=1.2, ls=style, color=colour,
                label="Budget Guard" if name == "guard" else name)
    op = [r for r in fr if r["rule"] == "guard" and r["param"] == "0.1"][0]
    ax.annotate("$\\delta{=}0.10$", (num(op["false_abort_rate"]),
                                     num(op["doomed_savings_frac"])),
                textcoords="offset points", xytext=(7, -3), fontsize=6.2, color=VIOLET)
    ax.set_xlabel("false-abort rate on feasible runs ($\\downarrow$)")
    ax.set_ylabel("doomed-run spend saved ($\\uparrow$)")
    ax.set_axisbelow(True)
    ax.grid(True)
    ax.legend(loc="lower right", handlelength=1.6, frameon=True,
              framealpha=0.92, edgecolor="none", borderpad=0.3)
    ax.set_title("(a) abort trade-off", fontsize=7.2, pad=3)

    ax = axes[1]
    agent = [r for r in cp if r["policy"] == "agent alone"][0]
    ax.scatter([1.0], [num(agent["cost_of_pass_usd"]) / 1e6], s=42, color=GRAY,
               marker="*", zorder=4, label="unstopped agent")
    for name, colour, marker, style in (("guard", VIOLET, "o", "-"),
                                        ("hard cap ($)", YELLOW, "s", ":")):
        pts = series(cp, "policy", name, "pass_rate_retained", "cost_of_pass_usd")
        ax.plot([p[0] for p in pts], [p[1] / 1e6 for p in pts], marker=marker, ms=3.0,
                lw=1.2, ls=style, color=colour,
                label="Budget Guard" if name == "guard" else name)
    g10 = [r for r in cp if r["policy"] == "guard" and r["param"] == "0.1"][0]
    ax.annotate("$\\delta{=}0.10$", (num(g10["pass_rate_retained"]),
                                     num(g10["cost_of_pass_usd"]) / 1e6),
                textcoords="offset points", xytext=(-30, 4), fontsize=6.2, color=VIOLET)
    ax.set_xlabel("successful runs retained ($\\uparrow$)")
    ax.set_ylabel("Cost-of-Pass, \\$M per pass ($\\downarrow$)")
    ax.set_axisbelow(True)
    ax.grid(True)
    ax.legend(loc="upper right", handlelength=1.6, frameon=True,
              framealpha=0.92, edgecolor="none", borderpad=0.3)
    ax.set_title("(b) Cost-of-Pass frontier", fontsize=7.2, pad=3)

    fig.savefig(os.path.join(OUT, "fig4_economics.pdf"), bbox_inches="tight",
                pad_inches=0.01)
    plt.close(fig)


if __name__ == "__main__":
    figure2()
    figure3()
    figure4()
    print("wrote fig2_coverage.pdf, fig3_transfer.pdf, fig4_economics.pdf")
