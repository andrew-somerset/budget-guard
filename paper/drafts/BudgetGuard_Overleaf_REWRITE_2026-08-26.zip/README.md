Budget Guard, Overleaf project, 2026-08-26 REWRITE.

main.tex: the main text (abstract through conclusion) rewritten for narrative clarity
around one thesis (budget awareness is two questions, how much more and whether to
stop, each needing its own calibrated instrument). Every number is unchanged and
traces to the verified source or to tables/case_study_sokoban*.csv. The preamble,
bibliography, appendices, and NeurIPS checklist are byte-identical to the 26 Aug
Overleaf source except for one appendix table (the worked-example numbers behind
Figure 1). Figures: fig_coverage.png and fig_transfer.png regenerated with the
corrected key at the originals' aspect ratios; fig_case_study.png is new;
fig_economics.png and pipeline.pdf are the team's originals.

Upload as a single zip (Overleaf: New Project > Upload Project). Main text ends on
page 9; references start on page 10.
