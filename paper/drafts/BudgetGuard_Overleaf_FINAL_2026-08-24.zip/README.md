# Budget Guard - complete Overleaf project (FINAL, 2026-08-24)

Upload as a new Overleaf project (New Project -> Upload Project). Main file:
main.tex. Compiles with pdfLaTeX. Bibliography embedded (no BibTeX step).

The team's Overleaf source with exactly the agreed fixes and the ORIGINAL
figure files (the ones the 9-page layout was tuned around):
1. Abstract + Conclusion: "on one split each" restored on the 18-of-19 claim.
2. Appendix C.9: BAGEN no-licence sentence + library licence list restored.
3. Checklist in the official NeurIPS template format, Q1/Q7 "headline number".

After compiling, confirm References start on page 9 (9-page main-text limit).
