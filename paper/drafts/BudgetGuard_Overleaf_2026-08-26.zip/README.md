Budget Guard, Overleaf project, 2026-08-26.

main.tex = the 2026-08-26 Overleaf source plus four agreed changes (paper/AUDIT_LOG.md
entry 6): worked example in Section 5.1 (paragraph + Table), two sentences in Section 6,
case-study figure in Appendix B, and regenerated fig_coverage.png / fig_transfer.png
with the corrected key. fig_economics.png and pipeline.pdf are the team's originals,
unchanged. Upload as a single zip (Overleaf: New Project > Upload Project) or replace the
individual files in the existing project.
