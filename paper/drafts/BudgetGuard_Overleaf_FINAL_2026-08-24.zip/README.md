# Budget Guard - complete Overleaf project (final, 2026-08-24)

Upload as a new Overleaf project (New Project -> Upload Project). Main file:
main.tex. Compiles with pdfLaTeX. Bibliography embedded (no BibTeX step).

This is the team's current Overleaf source with exactly the agreed fixes:
1. Abstract + Conclusion: "on one split each" restored on the 18-of-19 claim.
2. Appendix C.9: BAGEN no-licence sentence + library licence list restored.
3. Checklist in the official NeurIPS template format (Question/Answer/
   Justification/Guidelines), with Q1/Q7 saying "headline number".
4. Build necessity, extension only: the three results figures ship as .pdf
   (the repo's generated versions), so figures/fig_*.png references became
   figures/fig_*.pdf. If you prefer your own .png files, drop them into
   figures/ and change the three extensions back.

Note: the tail of the file (Appendix B tables, Appendix C, checklist) was
reconstructed from the compiled PDF because the source paste was truncated;
the content is verbatim, but if your Overleaf tail differs stylistically,
keep yours and apply only fixes 1-3.
